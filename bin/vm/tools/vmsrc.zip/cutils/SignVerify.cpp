// SignVerify.cpp
#include <jni.h>
#include <android/log.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>


// 来自hash256.cpp
extern "C" void sha256_hex(const void *data, size_t len, char out[65]);

#define LOG_TAG "SignVerify"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#define APK_SIG_BLOCK_MAGIC "APK Sig Block 42"
#define READ_U32_LE(p) \
    ((uint32_t)(p)[0] | ((uint32_t)(p)[1] << 8) | \
     ((uint32_t)(p)[2] << 16) | ((uint32_t)(p)[3] << 24))

#define READ_U64_LE(p) \
    ((uint64_t)READ_U32_LE(p) | ((uint64_t)READ_U32_LE((p)+4) << 32))
#define APK_SIG_V2_BLOCK_ID 0x7109871a
#define APK_SIG_V3_BLOCK_ID 0xf05368c0
#ifndef makedev
#define makedev(ma, mi) (((ma) << 8) | (mi))
#endif

// ======================= 取 APK 路径 =======================
static bool get_apk_path(JNIEnv *env, char out[512]) {
    (void)env;

    //LOGI("[SignVerify] 开始从 /proc/self/maps 解析 APK 路径");

    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) {
        //LOGE("[SignVerify] 无法打开 /proc/self/maps");
        return false;
    }

    char line[1024];
    char foundPath[512] = {0};

    while (fgets(line, sizeof(line), fp)) {
        // 示例行：
        // 12c00000-12d00000 r--p 00000000 fd:00 123456 /data/app/.../base.apk

        char *apkPos = strstr(line, "/base.apk");
        if (!apkPos) {
            continue;
        }

        // 向前找到路径起点（空格后）
        char *pathStart = apkPos;
        while (pathStart > line && *(pathStart - 1) != ' ') {
            pathStart--;
        }

        size_t len = strlen(pathStart);
        if (len >= sizeof(foundPath)) {
            //LOGE("[SignVerify] base.apk 路径过长，忽略");
            continue;
        }

        strncpy(foundPath, pathStart, len);
        foundPath[len] = '\0';

        // 去掉换行
        char *nl = strchr(foundPath, '\n');
        if (nl) *nl = '\0';

        //LOGI("[SignVerify] 命中候选 APK 路径：%s", foundPath);

        // 严格校验后缀
        size_t plen = strlen(foundPath);
        if (plen >= 9 && strcmp(foundPath + plen - 9, "/base.apk") == 0) {
            strncpy(out, foundPath, 511);
            out[511] = '\0';
            fclose(fp);

            //LOGI("[SignVerify] 最终确认 APK 路径：%s", out);
            return true;
        }

        //LOGE("[SignVerify] 路径未通过 base.apk 严格校验");
    }

    fclose(fp);

    //LOGE("[SignVerify] 未能从 maps 中找到合法的 base.apk 路径");
    return false;
}




// ======================= 核心：解析 V2 / V3 签名 =======================
static bool parse_apk_v2_v3_cert_sha256_hex(
        const uint8_t *apk,
        size_t apkSize,
        char outHex[65]) {

    //LOGI("[V2V3Parse] 开始解析 APK，apkSize=%zu", apkSize);

    if (!apk || apkSize < 32) {
        //LOGE("[V2V3Parse] APK 数据为空或长度异常");
        return false;
    }

    /* ===============================
     * 1. 查找 EOCD
     * =============================== */
    //LOGI("[V2V3Parse] 开始查找 EOCD");

    ssize_t eocdOffset = -1;
    for (ssize_t i = apkSize - 22; i >= 0 && i >= (ssize_t)(apkSize - 0x10000); i--) {
        if (READ_U32_LE(apk + i) == 0x06054b50) {
            eocdOffset = i;
            break;
        }
    }

    if (eocdOffset < 0) {
        //LOGE("[V2V3Parse] 未找到 EOCD");
        return false;
    }

    //LOGI("[V2V3Parse] 找到 EOCD，offset=%zd", eocdOffset);

    uint32_t cdOffset = READ_U32_LE(apk + eocdOffset + 16);
    uint32_t cdSize   = READ_U32_LE(apk + eocdOffset + 12);

    //LOGI("[V2V3Parse] CentralDirectory offset=%u size=%u", cdOffset, cdSize);

    if (cdOffset < 32 || cdOffset >= apkSize) {
        //LOGE("[V2V3Parse] CentralDirectory offset 异常");
        return false;
    }

    /* ===============================
     * 2. 定位 APK Signing Block
     * =============================== */
    size_t sigBlockEnd = cdOffset;

    /* Magic 位于 CentralDirectory 之前 16 字节 */
    const uint8_t *magicPos = apk + sigBlockEnd - 16;
    if (memcmp(magicPos, APK_SIG_BLOCK_MAGIC, 16) != 0) {
        //LOGE("[V2V3Parse] SigningBlock Magic 不匹配");
        return false;
    }

    /* size 位于 Magic 之前 8 字节 */
    uint64_t sigBlockSize = READ_U64_LE(magicPos - 8);

    //LOGI("[V2V3Parse] SigningBlock size=%llu",(unsigned long long)sigBlockSize);

    size_t sigBlockStart = sigBlockEnd - sigBlockSize - 8;
    if (sigBlockStart >= apkSize) {
        //LOGE("[V2V3Parse] SigningBlock 起始位置越界");
        return false;
    }

    //LOGI("[V2V3Parse] APK Signing Block 定位成功 start=%zu end=%zu",sigBlockStart, sigBlockEnd);

    const uint8_t *p = apk + sigBlockStart + 8;
    const uint8_t *sigEnd = apk + sigBlockEnd - 24;

    /* ===============================
     * 3. 遍历 ID-Value Pairs
     * =============================== */
    //LOGI("[V2V3Parse] 开始遍历 Signing Block");

    while (p < sigEnd) {
        uint64_t len = READ_U64_LE(p);
        p += 8;

        uint32_t id = READ_U32_LE(p);
        p += 4;

        //LOGI("[V2V3Parse] 发现 Block ID=0x%x len=%llu", id, (unsigned long long)len);

        if (id == APK_SIG_V2_BLOCK_ID || id == APK_SIG_V3_BLOCK_ID) {

            //LOGI("[V2V3Parse] 命中 APK Signature Scheme %s", id == APK_SIG_V2_BLOCK_ID ? "V2" : "V3");

            /* signer count */
            uint32_t signerCount = READ_U32_LE(p);
            //LOGI("[V2V3Parse] signerCount=%u", signerCount);

            if (signerCount == 0) {
                //LOGE("[V2V3Parse] signerCount 为 0");
                return false;
            }
            p += 4;

            /* 第一个 signer */
            uint32_t signerSize = READ_U32_LE(p);
            const uint8_t *signer = p + 4;

            //LOGI("[V2V3Parse] signerSize=%u", signerSize);

            uint32_t signedDataLen = READ_U32_LE(signer);
            const uint8_t *signedData = signer + 4;

            //LOGI("[V2V3Parse] signedDataLen=%u", signedDataLen);

            const uint8_t *sd = signedData;

            /* digests */
            uint32_t digestSeqLen = READ_U32_LE(sd);
            //LOGI("[V2V3Parse] digest 区块长度=%u", digestSeqLen);
            sd += 4 + digestSeqLen;

            /* certificates */
            uint32_t certSeqLen = READ_U32_LE(sd);
            //LOGI("[V2V3Parse] certificate 区块长度=%u", certSeqLen);
            sd += 4;

            if (certSeqLen < 8) {
                //LOGE("[V2V3Parse] certificate 区块长度异常");
                return false;
            }

            uint32_t certLen = READ_U32_LE(sd);
            const uint8_t *certDer = sd + 4;

            //LOGI("[V2V3Parse] 证书 DER 长度=%u", certLen);

            if (certLen == 0 || certDer + certLen > signedData + signedDataLen) {
                //LOGE("[V2V3Parse] 证书数据越界或非法");
                return false;
            }

            /* ===============================
             * 4. 计算证书 SHA-256
             * =============================== */
            memset(outHex, 0, 65);
            sha256_hex(certDer, certLen, outHex);

            //LOGI("[V2V3Parse] 证书 SHA256=%s", outHex);
            return true;
        }

        p += len - 4;
    }

    //LOGE("[V2V3Parse] 未找到 V2/V3 Signature Block");
    return false;
}


//=======================================================
static bool find_base_apk_inode(dev_t *outDev, ino_t *outInode) {
    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) {
        //LOGE("[SignVerify] 无法打开 /proc/self/maps");
        return false;
    }

    char line[1024];

    while (fgets(line, sizeof(line), fp)) {
        if (!strstr(line, "/base.apk")) continue;

        // maps 格式里 inode 在最后一列
        // 示例：fd:2f 3586495 /data/app/.../base.apk
        unsigned int major = 0, minor = 0;
        unsigned long inode = 0;

        if (sscanf(line, "%*s %*s %*s %x:%x %lu",
                   &major, &minor, &inode) == 3) {

            *outDev = makedev(major, minor);
            *outInode = (ino_t)inode;

            //LOGI("[SignVerify] maps 中 base.apk inode=%lu dev=%x:%x", inode, major, minor);

            fclose(fp);
            return true;
        }
    }

    fclose(fp);
    //LOGE("[SignVerify] maps 中未找到 base.apk inode");
    return false;
}
static bool open_and_verify_apk_fd(const char *path, int *outFd) {
    dev_t realDev;
    ino_t realInode;

    if (!find_base_apk_inode(&realDev, &realInode)) {
        return false;
    }

    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) {
        //LOGE("[SignVerify] open APK 失败：%s", path);
        return false;
    }

    struct stat st{};
    if (fstat(fd, &st) != 0) {
        close(fd);
        return false;
    }

    //LOGI("[SignVerify] open(fd) 得到 inode=%lu dev=%lx", (unsigned long)st.st_ino, (unsigned long)st.st_dev);

    if (st.st_ino != realInode || st.st_dev != realDev) {
        //LOGE("[SignVerify] APK FD inode/dev 不一致，疑似被重定向");
        close(fd);
        return false;
    }

    *outFd = fd;
    //LOGI("[SignVerify] APK FD inode 校验通过");
    return true;
}
static uint8_t *read_file_from_fd(int fd, size_t *outSize) {
    struct stat st;
    if (fstat(fd, &st) != 0 || st.st_size <= 0) {
        //LOGE("[SignVerify] fstat 失败");
        return NULL;
    }

    size_t size = (size_t)st.st_size;
    uint8_t *buf = (uint8_t *)malloc(size);
    if (!buf) {
        //LOGE("[SignVerify] 内存分配失败");
        return NULL;
    }

    ssize_t rd = pread(fd, buf, size, 0);
    close(fd);

    if (rd != (ssize_t)size) {
        //LOGE("[SignVerify] 读取 APK 内容失败");
        free(buf);
        return NULL;
    }

    *outSize = size;
    return buf;
}







// ======================= 对外入口 =======================
extern "C"
jboolean cn_verify_apk_signature_v2_v3(
        JNIEnv *env,
        jbyteArray outSha256) {

    //LOGI("[SignVerify] ===== 开始 APK V2/V3 Native 校验 =====");

    char apkPath[512] = {0};
    if (!get_apk_path(env, apkPath)) {
        return JNI_FALSE;
    }

    int apkFd = -1;
    if (!open_and_verify_apk_fd(apkPath, &apkFd)) {
        //LOGE("[SignVerify] APK 文件未通过 inode 校验");
        return JNI_FALSE;
    }

    size_t apkSize = 0;
    uint8_t *apk = read_file_from_fd(apkFd, &apkSize);
    if (!apk) {
        return JNI_FALSE;
    }

    char shaHex[65] = {0};
    bool ok = parse_apk_v2_v3_cert_sha256_hex(apk, apkSize, shaHex);
    free(apk);

    if (!ok) {
        //LOGE("[SignVerify] 签名解析失败");
        return JNI_FALSE;
    }

    //LOGI("[SignVerify] 证书 SHA256 = %s", shaHex);

    for (int i = 0; i < 32; i++) {
        char tmp[3] = { shaHex[i*2], shaHex[i*2+1], 0 };
        uint8_t b = (uint8_t)strtoul(tmp, nullptr, 16);
        env->SetByteArrayRegion(outSha256, i, 1, (jbyte*)&b);
    }

    //LOGI("[SignVerify] APK 签名校验完成");
    return JNI_TRUE;
}
