// cutils/InitEntry.cpp
#include "InitEntry.h"

// === 示例：后续你随便往这里加 ===

// static void anti_debug(JNIEnv *env) { }
// static void anti_hook(JNIEnv *env) { }
// static void runtime_env_check(JNIEnv *env) { }

void nmmp_init_entry(JNIEnv *env) {
    if (env == nullptr) {
        return;
    }

    // 现在先空实现，不影响任何逻辑
    // 后续你可以随便加
}
