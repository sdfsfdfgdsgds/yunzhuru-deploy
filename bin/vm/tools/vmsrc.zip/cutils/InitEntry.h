// cutils/InitEntry.h
#pragma once

#include <jni.h>

#ifdef __cplusplus
extern "C" {
#endif

void nmmp_init_entry(JNIEnv *env);

#ifdef __cplusplus
}
#endif
